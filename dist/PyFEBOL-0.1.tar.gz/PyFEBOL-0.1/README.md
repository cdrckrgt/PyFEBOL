# PyFEBOL

## Cedrick Argueta

a python rewrite of FEBOL
