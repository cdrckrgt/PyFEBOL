'''
entry point for PyFEBOL

by Cedrick Argueta

Stanford University
cdrckrgt@stanford.edu
cedrick@cs.stanford.edu
'''


